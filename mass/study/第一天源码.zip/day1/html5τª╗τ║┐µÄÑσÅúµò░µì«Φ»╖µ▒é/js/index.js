/**
 * Created by syLong on 2015/10/30.
 */
$(function () {
    var url = 'http://sjz.bokanedu.com/tgr/api/index.aspx';
    $.ajax({
        url:url+'?day=67&type=cache',
        type:'GET',
        dataType:'json',
        success: function (d) {
            $("img").attr('src', d.img[0].url);
            var HTML = '';
            for(var i = 0;i < d.data.length;i++){
                HTML += '<li><a href="'+ d.data[i].id+'">'+ d.data[i].title+'</a></li>';
            }
            $("#ul_con").append(HTML);
        }
    });
    window.applicationCache.addEventListener('updateready', function (e) {
        if(window.applicationCache.status == window.applicationCache.UPDATEREADY){
            window.applicationCache.swapCache();
            if(confirm("数据已更新，是否刷新？")){
                window.location.reload();
            }
        }
    },false);
});
