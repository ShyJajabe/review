var cook={
    setI:function(n,v){
        window.localStorage.setItem(n,v);
    },
    getI:function(n){
        return window.localStorage.getItem(n);
    }
}
var dd={
    curd:function(){
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth();
        var day = today.getDate();
        var hour = today.getHours();
        var min = today.getMinutes();
        var ruleDate=month + "/" + day + "/" + year + " " + hour + ":" + min;
        return ruleDate;
    },
    ask:function(){
        var hostUrl = 'http://sjz.bokanedu.com/tgr/api';
        var url = hostUrl + '/?day=4-4&type=html5';
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            success: function (d) {
                cook.setI("kdata", JSON.stringify(d));
                cook.setI("cookd",dd.curd());
            }
        })
    }
}
    if(cook.getI("kdata")!=null&&cook.getI("cookd")!=null) {
        var m1 = Date.parse(dd.curd()) - Date.parse(cook.getI("cookd"));
        var s1=m1/1000/60;
        if(Number(s1)>3){
            //��ʼ����
            dd.ask();
            console.log("������ʱ�䳬��������");
        }else{
            //��������ʹ��
            console.log("��������������");
            var djson=cook.getI("kdata");
            console.log(JSON.parse(djson)[0] );
        }
    }else {
        //1.ҳ���ʼ��ʱ
        dd.ask();
        console.log("�����״�Ҫ����");
    }