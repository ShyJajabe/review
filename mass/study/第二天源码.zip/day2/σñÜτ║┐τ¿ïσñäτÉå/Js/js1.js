/**
 * Created by tgrong on 2015/11/3.
 */
self.onmessage=function(d) {
    var num= d.data;
    var str = parseInt(num) % 2 == 0 ? '偶数' : '奇数';
    self.postMessage(str);
}
