/**
 * Created by tgrong on 2015/11/3.
 */

self.onmessage=function(d) {
    console.log(d.data);
    var obj = {}
    obj.val = d.data;
    obj.status = (!isNaN(d.data)) ? true : false;
    self.postMessage(obj);
}
