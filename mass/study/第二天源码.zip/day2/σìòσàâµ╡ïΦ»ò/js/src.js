/**
 * Created by lijianzhou on 16/10/12.
 */
var tgrong= {
    getName: function (n) {
        return n + 'hi';
    },
    reverse:function(t){
        return t.split("").reverse().join("");
    }
}
