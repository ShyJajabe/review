/**
 * Created by lijianzhou on 16/10/12.
 */
var jasmineEnv = jasmine.getEnv();
var htmlReporter = new jasmine.HtmlReporter();
jasmineEnv.addReporter(htmlReporter);
jasmineEnv.specFilter = function(spec) {
    return htmlReporter.specFilter(spec);
};
window.onload = function() {
    jasmineEnv.execute();
};
