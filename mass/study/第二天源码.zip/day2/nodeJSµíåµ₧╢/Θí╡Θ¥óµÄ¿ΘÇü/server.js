/**
 * Created by tgrong on 2015/10/22.
 */
var http = require('http'),
    io= require('socket.io');
var server=http.createServer(function (req, res) {
}).listen(8081);
console.log('Server running at http://127.0.0.1:8081/');
// 创建一个Socket.IO实例，把它传递给服务器
var socket= io.listen(server);
// 创建一个数组保存全部用户信息
var person=[];
// 添加一个连接监听器
socket.on('connection', function(client){
    // 成功！现在开始监听接收到的消息
    client.on('message',function(event){
        console.log('Received message from client!',event);
        if(event.code='1000'){
            person.push(event.text);
        }
        socket.send(event);
    });
    client.on('disconnect',function(){
        console.log('Server has disconnected');
    });
});
var ads=['早上好','上午好','中午好','下午好','晚上好']
var max= 5,i= 0,obj={};
var s1=setInterval(function(){
    if(i<max) {
        obj.code = '1001';
        obj.content = ads[i];
        socket.send(obj);
    }else{
        clearInterval(s1);
    }
    i++;
},5000)
var s2=setInterval(function(){
    console.log(person);
},5000)


