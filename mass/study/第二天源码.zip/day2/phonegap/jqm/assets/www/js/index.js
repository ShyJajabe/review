/**
 * Created by Ibokan on 2015/10/25.
 */
var start={
    allTime:61,
    nandu:120,
    lv:-1,
    finded:0,
    g:0,
    f:0,
    objt:null,
    init:function(){
        var eventName="ontouchstart" in document.documentElement?"touchstart":"click";
        $("#start").on(eventName,function(){
            window.clearInterval(start.objt);
            start.lv=-1;
            $("#index").fadeOut(1000);
            $("#room").fadeIn(1000);
            start.renderUI();
            start.renderBox();
            start.tick(eventName);
            start.timer(eventName);
            start.out(eventName);
        });
    },
    //绘制舞台，既box
    renderUI:function(){
        //判断是否横屏
        var isLandscape=90==window.orientation||-90==window.orientation;
        var width=isLandscape?window.innerHeight:window.innerWidth;
        width=width-20;
        width=Math.min(width,500);
        $("#box").css({width:width,height:width});
    },
    //绘制表格
    renderBox:function(){
        start.lv++;
        var g=config.lvMap[start.lv];
        if(start.lv>=17) g=9;
        var n=g*g;
        var c="";
        var d="lv"+g;
        var dd="lv"+(g-1);
        var h=start.nandu-g*10;
        var init=Math.floor(Math.random()*n);
        for(var i=0;i<n;i++){
            c+="<span></span>"
        }
        $("#box").removeClass(dd)
        $("#box").html(c).addClass(d);
        start.color(init,h);
        return start.g=g;
    },
    //绘制颜色与焦点颜色
    color:function(e,h){
        var r=255-Math.round(Math.random()*255);
        var g=255-Math.round(Math.random()*255);
        var b=255-Math.round(Math.random()*255);
        var ri=r+h;
        var gi=g+h;
        var bi=b+h;
        var color="rgb("+r+","+g+","+b+")";
        var color2="rgb("+ri+","+gi+","+bi+")";
        //设置颜色
        $("#box span").css({background:color});
        $("#box span").eq(e).css({background:color2});
        $("#box span").eq(e).attr("data-type",1);
    },
    //开始
    tick:function(v){
        $("#box span").on(v,function(){
            var a=$(this).attr("data-type");
            if(a==1){
                start.finded++;
                start.renderBox();
                $("#room .lv em").html(start.finded);
                start.tick(v);
            }
        })
    },
    //时间
    timer:function(v){
        //window.clearInterval(objt);
        start.objt=setInterval(function(){
            start.allTime=start.allTime-1;
            $("#room #time").html(start.allTime);
            if(start.allTime<6){
                $("#room #time").removeClass("time");
                $("#room #time").addClass("danger");
            }
            if(start.allTime<0){
                window.clearInterval(start.objt);
                start.gameover(v);
            }
        },1000);
    },
    //游戏结束
    gameover:function(v){
        $("#room").hide();
        $("#dialog").show();
        start.g=Math.round(start.finded/5);
        start.g>=8?start.g=8:start.g=start.g;
        $("#dialog h3").html(lang.lv_txt[start.g]+" "+"得分"+start.finded);
        var num=Math.round(Math.random()*100);
        var num2=Math.floor(80+start.g);
        $("#dialog #num").html(num);
        $("#dialog #num2").html(num2);
        $("#room .lv em").html("");
        $("#room #time").html("");
        $("#room #time").removeClass("danger");
        $("#room #time").addClass("time");
        start.restart(v);
    },
    reset:function(){
        start.allTime=61;
        start.finded=0;
        start.g=0;
        start.f=0;
        $("#box").removeAttr("class");
        $("#box").empty();
    },
    //重新开始
    restart:function(v){
        start.reset();
        $("#restart").on(v,function(){
            $(this).attr("data-index",1);
            $("#dialog").hide();
            $("#index").show();
            start.init();
        })
    },
    //退出游戏
    out:function(v){
        $("#out").on(v,function(){
            if(confirm("QAQ~您确定要离开我吗？")){
            window.close();//关闭窗口
            }
        })
    }
};
!function(){
    $("#loading").fadeOut(1000);
    $("#index").fadeIn(1000);
    if($("#restart").attr("data-index")==1){
        start.restart();
    }else{
        start.init();
    }
}();

